#!/bin/sh 
path=`pwd`
java -classpath ".:./lib/commons-logging-1.0.4.jar:./lib/commons-dbcp-1.4.jar:./lib/commons-pool-1.4.jar:./lib/log4j-1.2.8.jar:./lib/mysql-connector-java-5.1.15-bin.jar:./lib/ojdbc14.jar:./lib/dataSync.jar"  com.database.dataSyncMain  "$path"